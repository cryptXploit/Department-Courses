   import javax.swing.*;
   public class Task1C extends JFrame {
       public Task1C() {
           setTitle("My First GUI Frame");
           setSize(300, 300);
           setVisible(true);
       }
       public static void main(String[] args) { new Task1C(); }
   }








