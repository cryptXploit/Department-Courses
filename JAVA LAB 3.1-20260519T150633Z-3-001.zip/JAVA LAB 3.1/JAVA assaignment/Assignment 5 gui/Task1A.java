import java.awt.*;
import java.awt.event.*;

public class Task1A {
    public static void main(String[] args) {
        Frame f = new Frame("My First GUI Frame");

        f.setSize(300, 300);

        // Proper window closing handling
        f.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                f.dispose();
                System.exit(0);
            }
        });

        f.setVisible(true);
    }
}