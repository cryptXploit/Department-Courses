import javax.swing.*;
import java.awt.*;

public class Portfolio extends JFrame {

    CardLayout cardLayout;
    JPanel mainPanel;

    public Portfolio() {
        setTitle("My Portfolio");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Sidebar
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new GridLayout(6, 1, 10, 10));
        sidebar.setBackground(new Color(33, 37, 43));
        sidebar.setPreferredSize(new Dimension(150, 0));

        String[] menu = {"Home", "About", "Skills", "Projects", "Contact", "Exit"};

        // Main content with CardLayout
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        // Add pages
        mainPanel.add(createPage("Welcome to My Portfolio", "I am a Java Developer ??"), "Home");
        mainPanel.add(createPage("About Me", "I love coding and building apps."), "About");
        mainPanel.add(createPage("Skills", "Java, Swing, OOP, UI Design"), "Skills");
        mainPanel.add(createPage("Projects", "Student System, GUI Apps, Games"), "Projects");
        mainPanel.add(createPage("Contact", "Email: me@ru.ac.bd"), "Contact");

        // Buttons
        for (String item : menu) {
            JButton btn = new JButton(item);
            btn.setFocusPainted(false);
            btn.setForeground(Color.GREEN);
            btn.setBackground(new Color(232, 28, 14));
            btn.setFont(new Font("Arial", Font.BOLD, 24));

            btn.addActionListener(e -> {
                if (item.equals("Exit")) {
                    System.exit(0);
                } else {
                    cardLayout.show(mainPanel, item);
                }
            });

            sidebar.add(btn);
        }

        add(sidebar, BorderLayout.WEST);
        add(mainPanel, BorderLayout.CENTER);

        setVisible(true);
    }

    // Method to create pages
    private JPanel createPage(String titleText, String bodyText) {
        JPanel panel = new JPanel();
        panel.setBackground(new Color(248, 249, 250));
        panel.setLayout(new BorderLayout());

        JLabel title = new JLabel(titleText, JLabel.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));

        JLabel body = new JLabel(bodyText, JLabel.CENTER);
        body.setFont(new Font("Arial", Font.PLAIN, 16));

        panel.add(title, BorderLayout.NORTH);
        panel.add(body, BorderLayout.CENTER);

        return panel;
    }

    public static void main(String[] args) {
        new Portfolio();
    }
}



