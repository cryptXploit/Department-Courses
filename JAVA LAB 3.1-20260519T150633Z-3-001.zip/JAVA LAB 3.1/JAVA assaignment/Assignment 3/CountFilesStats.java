import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class CountFileStats {
    public static void main(String[] args) {
        int lines = 0, words = 0, chars = 0;

        try {
            BufferedReader reader = new BufferedReader(new FileReader("student.txt"));
            String line;

            while ((line = reader.readLine()) != null) {
                lines++;
                chars += line.length();
                words += line.split("\\s+").length;
            }

            reader.close();

            System.out.println("Lines: " + lines);
            System.out.println("Words: " + words);
            System.out.println("Characters: " + chars);
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
