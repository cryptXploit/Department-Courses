import java.io.*;
import java.util.Scanner;

public class RandomAccessStudent {
    static final int NAME_LENGTH = 20; // fixed length name
    static final int RECORD_SIZE = 4 + NAME_LENGTH * 2 + 8;
    // int(4) + name(20*2) + double(8)

    public static void writeRecord(RandomAccessFile file, int id, String name, double gpa) throws IOException {
        file.writeInt(id);

        StringBuilder sb = new StringBuilder(name);
        sb.setLength(NAME_LENGTH); // fixed length
        file.writeChars(sb.toString());

        file.writeDouble(gpa);
    }

    public static void readRecord(RandomAccessFile file, int position) throws IOException {
        file.seek(position * RECORD_SIZE);

        int id = file.readInt();

        char[] nameChars = new char[NAME_LENGTH];
        for (int i = 0; i < NAME_LENGTH; i++) {
            nameChars[i] = file.readChar();
        }
        String name = new String(nameChars).trim();

        double gpa = file.readDouble();

        System.out.println("ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("GPA: " + gpa);
    }

    public static void main(String[] args) {
        try {
            RandomAccessFile file = new RandomAccessFile("students.dat", "rw");
            Scanner sc = new Scanner(System.in);

            while (true) {
                System.out.println("\n1.Add Record");
                System.out.println("2.Read Record by Position");
                System.out.println("3.Update GPA");
                System.out.println("4.Exit");
                System.out.print("Choice: ");
                int choice = sc.nextInt();

                if (choice == 1) {
                    System.out.print("Enter ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter GPA: ");
                    double gpa = sc.nextDouble();

                    file.seek(file.length());
                    writeRecord(file, id, name, gpa);
                }
                else if (choice == 2) {
                    System.out.print("Enter record position (0,1,2...): ");
                    int pos = sc.nextInt();
                    readRecord(file, pos);
                }
                else if (choice == 3) {
                    System.out.print("Enter record position to update GPA: ");
                    int pos = sc.nextInt();
                    System.out.print("Enter new GPA: ");
                    double newGpa = sc.nextDouble();

                    file.seek(pos * RECORD_SIZE + 4 + NAME_LENGTH * 2);
                    file.writeDouble(newGpa);
                }
                else {
                    break;
                }
            }

            file.close();
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
