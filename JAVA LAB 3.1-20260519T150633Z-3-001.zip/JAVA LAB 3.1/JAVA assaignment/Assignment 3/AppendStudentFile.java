import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class AppendStudentFile {
    public static void main(String[] args) {
        try {
            Scanner sc = new Scanner(System.in);

            System.out.print("Enter Name: ");
            String name = sc.nextLine();

            System.out.print("Enter ID: ");
            String id = sc.nextLine();

            System.out.print("Enter Department: ");
            String dept = sc.nextLine();

            FileWriter writer = new FileWriter("student.txt", true);
            writer.write("\nName: " + name + "\n");
            writer.write("ID: " + id + "\n");
            writer.write("Department: " + dept + "\n");
            writer.close();

            System.out.println("New student info appended!");
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}

