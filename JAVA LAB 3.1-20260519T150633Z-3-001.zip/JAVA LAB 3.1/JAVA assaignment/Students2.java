import java.util.Scanner;

class Student {
    private String name;
    private int age;

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        if (age > 0) {
            this.age = age;
        }
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }
}

class Students2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("How many students? ");
        int n = sc.nextInt();
        sc.nextLine(); // clear buffer

        for (int i = 1; i <= n; i++) {
            Student s = new Student();

            System.out.println("\nStudent " + i);

            System.out.print("Enter name: ");
            String name = sc.nextLine();

            System.out.print("Enter age: ");
            int age = sc.nextInt();
            sc.nextLine(); // clear buffer

            s.setName(name);
            s.setAge(age);

            System.out.println("Saved -> Name: " + s.getName() + ", Age: " + s.getAge());
        }

        sc.close();
    }
}
