import java.util.Scanner;

class JaggedArr {
    int[][] arr;

    public JaggedArr(int rows) { // [cite: 12]
        arr = new int[rows][];
    }

    public void jaggedInput() {
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < arr.length; i++) {
            System.out.print("Enter elements for row " + (i + 1) + ": ");
            int cols = sc.nextInt();
            arr[i] = new int[cols];
            for (int j = 0; j < cols; j++) {
                arr[i][j] = sc.nextInt();
            }
        }
    }

    public void jaggedOutput() {
        System.out.println("Jagged Array Elements:");
        for (int[] row : arr) {
            for (int val : row) System.out.print(val + " ");
            System.out.println();
        }
    }
}

public class JaggedArrTest {
    public static void main(String[] args) {
        JaggedArr ja = new JaggedArr(3);
        ja.jaggedInput();
        ja.jaggedOutput();
    }
}