import java.io.*;
import java.util.Scanner;

public class FileOperations {
    public static void main(String[] args) {
        String fileName = "student.txt";

        // Task 1 & 2: Create and Write [cite: 1, 2]
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            writer.write("John Doe, 101, CSE\n");
            writer.write("Jane Smith, 102, EEE\n");
            System.out.println("File created and initial details written.");
        } catch (IOException e) {
            System.out.println("An error occurred during writing.");
        }

        // Task 4: Append [cite: 4]
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true))) {
            writer.write("Alice Brown, 103, SWE\n");
            System.out.println("New student appended successfully.");
        } catch (IOException e) {
            System.out.println("Append failed.");
        }

        // Task 3: Read and Display [cite: 3]
        System.out.println("\n--- Student Details ---");
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println("Read error.");
        }

        // Task 5: Statistics [cite: 5]
        analyzeFile(fileName);

        // Task 5 (Part 2): Copy File
        copyFile(fileName, "destination.txt");
    }

    public static void analyzeFile(String fileName) {
        int lines = 0, words = 0, characters = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines++;
                characters += line.length();
                words += line.trim().isEmpty() ? 0 : line.trim().split("\\s+").length;
            }
            System.out.println("\nFile Stats: Lines: " + lines + ", Words: " + words + ", Chars: " + characters);
        } catch (IOException e) { e.printStackTrace(); }
    }

    public static void copyFile(String src, String dest) {
        try (InputStream in = new FileInputStream(src); OutputStream out = new FileOutputStream(dest)) {
            byte[] buffer = new byte[1024];
            int length;
            while ((length = in.read(buffer)) > 0) {
                out.write(buffer, 0, length);
            }
            System.out.println("Contents copied to " + dest);
        } catch (IOException e) { e.printStackTrace(); }
    }
}