import java.util.Scanner;

class Student { // [cite: 14]
    int rollNo;
    String name;
    double marks;

    void input() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Roll, Name, Marks: ");
        rollNo = sc.nextInt();
        name = sc.next();
        marks = sc.nextDouble();
    }

    void display() {
        System.out.println(name + " (Roll: " + rollNo + ") - Marks: " + marks + " - Grade: " + grade());
    }

    String grade() {
        if (marks >= 80) return "A+";
        if (marks >= 60) return "A";
        return "B";
    }
}

class Employee { // [cite: 15]
    int id;
    String name;
    Employee(int id, String name) { this.id = id; this.name = name; }
}

class Salary extends Employee { // [cite: 16]
    double basic;
    Salary(int id, String name, double basic) {
        super(id, name);
        this.basic = basic;
    }

    void calculateAndDisplay() {
        double hra = 0.5 * basic; // [cite: 16]
        double ta = 0.1 * basic;  // [cite: 17]
        double gross = basic + hra + ta;
        double tax = 0.3 * gross; // [cite: 17]
        double net = gross - tax;
        System.out.println("Net Pay: " + net);
    }
}

public class StudentEmployeeDemo {
    public static void main(String[] args) {
        Student s = new Student();
        s.input();
        s.display();

        Salary emp = new Salary(101, "Karim", 50000);
        emp.calculateAndDisplay();
    }
}