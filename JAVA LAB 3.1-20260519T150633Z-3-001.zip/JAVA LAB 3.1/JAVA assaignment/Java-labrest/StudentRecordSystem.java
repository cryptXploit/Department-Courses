import java.io.*;
import java.util.Scanner;

public class StudentRecordSystem {
    private static final int RECORD_SIZE = 4 + 40 + 8; // ID (int) + Name (20 chars = 40 bytes) + GPA (double) [cite: 7]

    public static void main(String[] args) throws IOException {
        RandomAccessFile raf = new RandomAccessFile("students.dat", "rw"); // [cite: 8]
        Scanner sc = new Scanner(System.in);

        // Add Records [cite: 9]
        addRecord(raf, 1, "John Doe", 3.8);
        addRecord(raf, 2, "Jane Smith", 3.9);

        // Retrieve Record [cite: 10]
        System.out.print("Enter ID to retrieve: ");
        displayRecord(raf, sc.nextInt());

        // Update GPA [cite: 11]
        System.out.print("Enter ID to update GPA: ");
        int updateId = sc.nextInt();
        System.out.print("Enter new GPA: ");
        updateGPA(raf, updateId, sc.nextDouble());

        raf.close();
    }

    public static void addRecord(RandomAccessFile raf, int id, String name, double gpa) throws IOException {
        raf.seek((long) (id - 1) * RECORD_SIZE);
        raf.writeInt(id);
        StringBuilder sb = new StringBuilder(name);
        sb.setLength(20);
        raf.writeChars(sb.toString());
        raf.writeDouble(gpa);
    }

    public static void displayRecord(RandomAccessFile raf, int id) throws IOException {
        raf.seek((long) (id - 1) * RECORD_SIZE);
        if (raf.length() < (long) id * RECORD_SIZE) {
            System.out.println("Record not found.");
            return;
        }
        int sId = raf.readInt();
        String name = "";
        for (int i = 0; i < 20; i++) name += raf.readChar();
        double gpa = raf.readDouble();
        System.out.println("ID: " + sId + " | Name: " + name.trim() + " | GPA: " + gpa);
    }

    public static void updateGPA(RandomAccessFile raf, int id, double newGpa) throws IOException {
        raf.seek((long) (id - 1) * RECORD_SIZE + 44); // Skip ID and Name
        raf.writeDouble(newGpa);
        System.out.println("GPA updated.");
    }
}