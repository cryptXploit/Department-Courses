import java.util.Scanner;

public class UtilityPrograms {
    // Method Overloading
    void area(double r) { System.out.println("Circle: " + (Math.PI * r * r)); }
    void area(int l, int w) { System.out.println("Rectangle: " + (l * w)); }
    void area(double b, double h) { System.out.println("Triangle: " + (0.5 * b * h)); }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // String Handling [cite: 18]
        System.out.print("Enter string: ");
        String str = sc.nextLine().toLowerCase();
        int v = 0, c = 0, d = 0, s = 0;
        for (char ch : str.toCharArray()) {
            if ("aeiou".indexOf(ch) != -1) v++;
            else if (ch >= 'a' && ch <= 'z') c++;
            else if (Character.isDigit(ch)) d++;
            else if (Character.isWhitespace(ch)) s++;
        }
        System.out.println("Vowels: " + v + ", Consonants: " + c + ", Digits: " + d + ", Spaces: " + s);

        // Palindrome Check [cite: 19, 20]
        System.out.print("Enter number: ");
        int num = sc.nextInt(), reversed = 0, temp = num;
        while (temp != 0) {
            reversed = reversed * 10 + temp % 10;
            temp /= 10;
        }
        System.out.println(num == reversed ? "Palindrome" : "Not Palindrome");
    }
}