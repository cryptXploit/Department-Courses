import java.util.*;

class Fruit {
    int id;
    String name;
    double price;

    public Fruit(int id, String name, double price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Name: " + name + ", Price: " + price;
    }
}

public class FruitManager {
    public static void main(String[] args) {
        List<Fruit> fruits = new ArrayList<>(); // [cite: 13]
        fruits.add(new Fruit(1, "Mango", 150));
        fruits.add(new Fruit(2, "Apple", 250));
        fruits.add(new Fruit(3, "Banana", 60));

        // Sorting by Price
        fruits.sort(Comparator.comparingDouble(f -> f.price));
        System.out.println("Sorted by Price (Asc): " + fruits);

        // Sorting by Name
        fruits.sort(Comparator.comparing(f -> f.name));
        System.out.println("Sorted by Name: " + fruits);

        // Most and Least Expensive
        Fruit max = Collections.max(fruits, Comparator.comparingDouble(f -> f.price));
        Fruit min = Collections.min(fruits, Comparator.comparingDouble(f -> f.price));
        System.out.println("Most Expensive: " + max.name);
        System.out.println("Cheapest: " + min.name);
    }
}