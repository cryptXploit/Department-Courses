import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

class Fruit {
    int id;
    String name;
    double price;

    Fruit(int id, String name, double price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    void display() {
        System.out.println(id + " " + name + " " + price);
    }

    public static void main(String[] args) {
        ArrayList<Fruit> fruits = new ArrayList<>();

        fruits.add(new Fruit(1, "Apple", 120));
        fruits.add(new Fruit(2, "Banana", 60));
        fruits.add(new Fruit(3, "Mango", 150));
        fruits.add(new Fruit(4, "Orange", 80));

        // Display all fruits
        System.out.println("All Fruits:");
        for (Fruit f : fruits) {
            f.display();
        }

        // Most expensive fruit
        Fruit max = Collections.max(fruits, Comparator.comparingDouble(f -> f.price));
        System.out.println("\nMost Expensive Fruit:");
        max.display();

        // Cheapest fruit
        Fruit min = Collections.min(fruits, Comparator.comparingDouble(f -> f.price));
        System.out.println("\nCheapest Fruit:");
        min.display();

        // Sort by price
        fruits.sort(Comparator.comparingDouble(f -> f.price));
        System.out.println("\nSorted by Price:");
        for (Fruit f : fruits) {
            f.display();
        }

        // Sort by name
        fruits.sort(Comparator.comparing(f -> f.name));
        System.out.println("\nSorted by Name:");
        for (Fruit f : fruits) {
            f.display();
        }
    }
}

