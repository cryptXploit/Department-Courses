import java.util.Scanner;

public class JaggedArr {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        // Ask user how many rows they want
        System.out.print("Enter number of rows: ");
        int numberOfRows = scanner.nextInt();

        // Create jagged array (only rows for now)
        int[][] jaggedArray = new int[numberOfRows][];

        // Take input for each row
        for (int i = 0; i < numberOfRows; i++) {

            System.out.print("Enter number of elements for row " + (i + 1) + ": ");
            int numberOfColumns = scanner.nextInt();

            // Create row with given size
            jaggedArray[i] = new int[numberOfColumns];

            System.out.println("Enter " + numberOfColumns + " numbers:");

            // Take elements for this row
            for (int j = 0; j < numberOfColumns; j++) {
                jaggedArray[i][j] = scanner.nextInt();
            }
        }

        // Print the jagged array
        System.out.println("\nJagged Array Output:");

        for (int i = 0; i < jaggedArray.length; i++) {
            for (int j = 0; j < jaggedArray[i].length; j++) {
                System.out.print(jaggedArray[i][j] + " ");
            }
            System.out.println();
        }

        scanner.close();
    }
}