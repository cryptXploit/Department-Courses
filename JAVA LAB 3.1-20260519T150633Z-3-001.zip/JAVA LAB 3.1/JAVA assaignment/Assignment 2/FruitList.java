import java.util.ArrayList;
import java.util.Scanner;

class FruitList {
    public static void main(String[] args) {
        ArrayList<String> fruits = new ArrayList<>();
        Scanner sc = new Scanner(System.in);

        // Add fruits
        fruits.add("Apple");
        fruits.add("Banana");
        fruits.add("Mango");
        fruits.add("Orange");

        // Display fruits
        System.out.println("Fruits List:");
        System.out.println(fruits);

        // Remove a fruit
        fruits.remove("Banana");
        System.out.println("After removing Banana:");
        System.out.println(fruits);

        // Search a fruit
        System.out.print("Enter fruit name to search: ");
        String search = sc.nextLine();

        if (fruits.contains(search)) {
            System.out.println(search + " is found.");
        } else {
            System.out.println(search + " is not found.");
        }
    }
}
