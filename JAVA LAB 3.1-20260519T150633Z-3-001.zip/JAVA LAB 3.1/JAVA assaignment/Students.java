class Student {
    private String name;
    private int age;

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setAge(int age) {
        if (age > 0) {
            this.age = age;
        }
    }

    public int getAge() {
        return age;
    }
}

class Students {
    public static void main(String[] args) {
        Student s = new Student();

        s.setName("Rahim");
        s.setAge(20);
        s.setName("Rahim2");
        s.setAge(205);

        System.out.println("Name: " + s.getName());
        System.out.println("Age: " + s.getAge());
    }
}
