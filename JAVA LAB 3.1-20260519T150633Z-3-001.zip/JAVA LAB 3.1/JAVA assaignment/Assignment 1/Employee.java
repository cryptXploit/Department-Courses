import java.util.Scanner;

public class Employee {
    int id;
    String name;
    double basicPay;

    public void inputBasicDetails() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter Employee ID: ");
        id = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter Employee Name: ");
        name = scanner.nextLine();

        System.out.print("Enter Basic Pay: ");
        basicPay = scanner.nextDouble();
    }

    public static void main(String[] args) {
        Salary s = new Salary();

        System.out.println("--- Enter Employee Details ---");
        s.inputBasicDetails();
        s.calculateAndDisplay();
    }
}

class Salary extends Employee {
    double hra;
    double ta;
    double grossSalary;
    double tax;
    double netPay;

    public void calculateAndDisplay() {
        hra = 0.50 * basicPay;
        ta = 0.10 * basicPay;

        grossSalary = basicPay + hra + ta;
        tax = 0.30 * grossSalary;
        netPay = grossSalary - tax;

        System.out.println("\n--- Salary Details ---");
        System.out.println("Employee ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Basic Pay: " + basicPay);
        System.out.println("HRA (50%): " + hra);
        System.out.println("TA (10%): " + ta);
        System.out.println("Gross Salary: " + grossSalary);
        System.out.println("Tax (30%): " + tax);
        System.out.println("Net Pay: " + netPay);
    }
}
