import java.util.Scanner;

public class CharacterCounter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a string: ");
        String inputString = scanner.nextLine().toLowerCase(); // Convert to lowercase for easy vowel check

        int vowels = 0, consonants = 0, digits = 0, spaces = 0;

        for (int i = 0; i < inputString.length(); ++i) {
            char ch = inputString.charAt(i);

            if (ch >= 'a' && ch <= 'z') { // Check if character is a letter
                if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                    vowels++;
                } else {
                    consonants++;
                }
            } else if (ch >= '0' && ch <= '9') { // Check if character is a digit
                digits++;
            } else if (ch == ' ') { // Check if character is a space
                spaces++;
            }
        }

        System.out.println("Vowels: " + vowels);
        System.out.println("Consonants: " + consonants);
        System.out.println("Digits: " + digits);
        System.out.println("White spaces: " + spaces);
    }
}



