import java.util.Scanner;

class Student {
    int rollNo;
    String name;
    double marks;

    public void input() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter Roll No: ");
        rollNo = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter Name: ");
        name = scanner.nextLine();

        System.out.print("Enter Marks: ");
        marks = scanner.nextDouble();
    }

    public void display() {
        System.out.println("Roll No: " + rollNo);
        System.out.println("Name: " + name);
        System.out.println("Marks: " + marks);
    }

    public void grade() {
        if (marks >= 80) {
            System.out.println("Grade: A+");
        } else if (marks >= 70) {
            System.out.println("Grade: A");
        } else if (marks >= 60) {
            System.out.println("Grade: B");
        } else if (marks >= 50) {
            System.out.println("Grade: C");
        } else if (marks >= 40) {
            System.out.println("Grade: D");
        } else if (marks >= 33) {
            System.out.println("Grade: E");
        } else {
            System.out.println("Grade: Fail");
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Student s1 = new Student();

        System.out.println("--- Enter Student Details ---");
        s1.input();

        System.out.println("\n--- Student Details ---");
        s1.display();
        s1.grade();
    }
}
