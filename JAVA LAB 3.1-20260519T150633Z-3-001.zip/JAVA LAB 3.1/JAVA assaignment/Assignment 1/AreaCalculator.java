public class AreaCalculator {

    public double area(double radius) {
        return Math.PI * radius * radius;
    }

    public double area(double length, double width) {
        return length * width;
    }

    public double area(double base, double height, int dummy) {
        return 0.5 * base * height;
    }

    public static void main(String[] args) {
        AreaCalculator calc = new AreaCalculator();

        System.out.println("Area of Circle: " + calc.area(5.0));
        System.out.println("Area of Rectangle: " + calc.area(4.0, 6.0));
        System.out.println("Area of Triangle: " + calc.area(3.0, 5.0, 1));
    }
}
