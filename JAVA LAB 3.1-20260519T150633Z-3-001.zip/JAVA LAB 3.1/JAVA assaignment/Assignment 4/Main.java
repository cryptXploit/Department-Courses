import shapes.Circle;
import shapes.Rectangle;

public class Main {
    public static void main(String[] args) {


        Circle circle = new Circle(5);
        Rectangle rectangle = new Rectangle(4, 6);


        double circleArea = circle.calculateArea();
        double rectangleArea = rectangle.calculateArea();


        System.out.println("Area of Circle: " + circleArea);
        System.out.println("Area of Rectangle: " + rectangleArea);
    }
}