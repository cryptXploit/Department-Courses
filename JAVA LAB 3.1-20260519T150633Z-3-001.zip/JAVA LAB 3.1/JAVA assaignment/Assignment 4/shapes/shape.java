package shapes;

public interface shape {
    double calculateArea();
}