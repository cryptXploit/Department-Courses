import java.io.*;

public class SelfFileProcessor {
    public static void main(String[] args) {
        try {
            // Name of the current program file
            String fileName = "SelfFileProcessor.java";

            FileInputStream fis = new FileInputStream(fileName);

            // Read entire file into byte array
            byte[] data = fis.readAllBytes();
            fis.close();

            int length = data.length;
            int quarter = length / 4;

            // Calculate ranges
            int q1_end = quarter;
            int q2_end = 2 * quarter;
            int q3_end = 3 * quarter;

            // Display second quarter
            System.out.println("---- Second Quarter ----");
            for (int i = q1_end; i < q2_end; i++) {
                System.out.print((char) data[i]);
            }

            // Write third and fourth quarters into File1.txt
            FileOutputStream fos = new FileOutputStream("File1.txt");

            for (int i = q2_end; i < length; i++) {
                fos.write(data[i]);
            }

            fos.close();

            System.out.println("\n\nThird and Fourth quarters written to File1.txt");

        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}