import java.util.Scanner;

// Base class
class StringProcessor {
    String text;

    // Method to set string
    void setString(String text) {
        this.text = text;
    }

    // Method to display string
    void displayString() {
        System.out.println("Entered String: " + text);
    }
}

class StringAnalyzer extends StringProcessor {

    int countVowels() {
        int count = 0;
        String t = text.toLowerCase();

        for (int i = 0; i < t.length(); i++) {
            char ch = t.charAt(i);
            if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                count++;
            }
        }
        return count;
    }

    int countConsonants() {
        int count = 0;
        String t = text.toLowerCase();

        for (int i = 0; i < t.length(); i++) {
            char ch = t.charAt(i);
            if (ch >= 'a' && ch <= 'z' &&
               !(ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u')) {
                count++;
            }
        }
        return count;
    }

    int countDigits() {
        int count = 0;

        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            if (ch >= '0' && ch <= '9') {
                count++;
            }
        }
        return count;
    }

    int countWhiteSpaces() {
        int count = 0;

        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            if (ch == ' ') {
                count++;
            }
        }
        return count;
    }
}

// Main class
public class TestAnalyzer {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String input = sc.nextLine();

        StringAnalyzer obj = new StringAnalyzer();

        obj.setString(input);       // from base class
        obj.displayString();        // from base class

        System.out.println("Vowels: " + obj.countVowels());
        System.out.println("Consonants: " + obj.countConsonants());
        System.out.println("Digits: " + obj.countDigits());
        System.out.println("White Spaces: " + obj.countWhiteSpaces());
    }
}