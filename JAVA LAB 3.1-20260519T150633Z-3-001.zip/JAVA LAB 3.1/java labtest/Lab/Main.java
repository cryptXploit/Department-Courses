import java.util.Scanner;


class StringInput {
    protected String text;

    public void readString() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a string");
        text = scanner.nextLine();
    }
}


class StringAnalyzer extends StringInput {

    public void analyze() {
        int vowels = 0, consonants = 0, digits = 0, spaces = 0;


        String lowerText = text.toLowerCase();

        for (int i = 0; i < lowerText.length(); i++) {
            char ch = lowerText.charAt(i);

            if (ch >= 'a' && ch <= 'z') {
                if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                    vowels++;
                } else {
                    consonants++;
                }
            } else if (ch >= '0' && ch <= '9') {
                digits++;
            } else if (Character.isWhitespace(ch)) {
                spaces++;
            }
        }

        displayResults(vowels, consonants, digits, spaces);
    }

    private void displayResults(int v, int c, int d, int s) {
        System.out.println("\n--- Analysis Results ---");
        System.out.println("Vowels: " + v);
        System.out.println("Consonants: " + c);
        System.out.println("Digits: " + d);
        System.out.println("White Spaces: " + s);
    }
}

public class Main {
    public static void main(String[] args) {
        StringAnalyzer analyzer = new StringAnalyzer();


        analyzer.readString();


        analyzer.analyze();
    }
}
