import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.File;
import java.io.IOException;

public class Program {
    public static void main(String[] args) {

        String fileName = "Main.java";
        File file = new File(fileName);
        long fileLength = file.length();


        int quarter = (int) (fileLength / 4);

        try (
            FileInputStream fis = new FileInputStream(file);
            FileOutputStream fos = new FileOutputStream("file.txt")
        ) {

            fis.skip(quarter);


            System.out.println("--- Displaying Second Quarter ---");
            for (int i = 0; i < quarter; i++) {
                int data = fis.read();
                if (data != -1) {
                    System.out.print((char) data);
                }
            }
            System.out.println("\n\n[End of Second Quarter]");


            int data;
            while ((data = fis.read()) != -1) {
                fos.write(data);
            }

            System.out.println("Success: Third and fourth quarters written to 'file.txt'.");

        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }
}