import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileQuarterProcessor {
    public static void main(String[] args) {

        File file = new File("FileQuarterProcessor.java");

        if (!file.exists()) {
            System.out.println("File not found! Please ensure the filename matches.");
            return;
        }

        long fileSize = file.length();
        int quarter = (int) (fileSize / 4);

        try (FileInputStream fis = new FileInputStream(file);
             FileOutputStream fos = new FileOutputStream("File1.txt")) {


            fis.skip(quarter);


            System.out.println("--- Second Quarter of the File ---");
            for (int i = 0; i < quarter; i++) {
                int data = fis.read();
                if (data != -1) {
                    System.out.print((char) data);
                }
            }
            System.out.println("\n\n--- End of Second Quarter ---");


            int b;
            while ((b = fis.read()) != -1) {
                fos.write(b);
            }

            System.out.println("Success: 3rd and 4th quarters written to File1.txt");

        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }
}