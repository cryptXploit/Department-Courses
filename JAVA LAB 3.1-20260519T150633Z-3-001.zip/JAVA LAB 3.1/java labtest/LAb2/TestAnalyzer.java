import java.util.Scanner;


class StringProcessor {
    protected String text;


    void setString(String text) {
        this.text = text;
    }


    void displayString() {
        System.out.println("\nAnalyzing String: " + text);
    }
}


class StringAnalyzer extends StringProcessor {

    int countVowels() {
        int count = 0;
        String temp = text.toLowerCase();
        for (int i = 0; i < temp.length(); i++) {
            char ch = temp.charAt(i);
            if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                count++;
            }
        }
        return count;
    }

    int countConsonants() {
        int count = 0;
        String temp = text.toLowerCase();
        for (int i = 0; i < temp.length(); i++) {
            char ch = temp.charAt(i);
            if (ch >= 'a' && ch <= 'z') {
                if (!(ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u')) {
                    count++;
                }
            }
        }
        return count;
    }

    int countDigits() {
        int count = 0;
        for (int i = 0; i < text.length(); i++) {
            if (Character.isDigit(text.charAt(i))) {
                count++;
            }
        }
        return count;
    }

    int countWhiteSpace() {
        int count = 0;
        for (int i = 0; i < text.length(); i++) {
            if (Character.isWhitespace(text.charAt(i))) {
                count++;
            }
        }
        return count;
    }
}


public class TestAnalyzer {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);


        StringAnalyzer analyzer = new StringAnalyzer();

        System.out.print("Enter a string to analyze: ");
        String input = sc.nextLine();


        analyzer.setString(input);


        analyzer.displayString();
        System.out.println("------------------------------");
        System.out.println("Vowels:       " + analyzer.countVowels());
        System.out.println("Consonants:   " + analyzer.countConsonants());
        System.out.println("Digits:       " + analyzer.countDigits());
        System.out.println("White Space:  " + analyzer.countWhiteSpace());
        System.out.println("------------------------------");

        sc.close();
    }
}